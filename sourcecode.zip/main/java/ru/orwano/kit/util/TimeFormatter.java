package ru.orwano.kit.util;

public final class TimeFormatter {

    private TimeFormatter() {
    }

    public static String format(long totalSeconds) {
        long seconds = Math.max(0, totalSeconds);
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long restSeconds = seconds % 60;
        StringBuilder result = new StringBuilder();
        if (hours > 0) {
            result.append(hours).append(" ч. ");
        }
        if (minutes > 0) {
            result.append(minutes).append(" мин. ");
        }
        if (restSeconds > 0 || result.isEmpty()) {
            result.append(restSeconds).append(" сек. ");
        }
        return result.toString().trim();
    }
}
