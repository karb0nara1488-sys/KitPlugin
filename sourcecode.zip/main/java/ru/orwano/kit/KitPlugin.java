package ru.orwano.kit;

import org.bukkit.plugin.java.JavaPlugin;
import ru.orwano.kit.command.KitCommand;
import ru.orwano.kit.config.KitConfig;
import ru.orwano.kit.cooldown.CooldownManager;
import ru.orwano.kit.gui.KitMenuListener;
import ru.orwano.kit.kit.KitService;

public final class KitPlugin extends JavaPlugin {

    private KitConfig kitConfig;
    private CooldownManager cooldownManager;
    private KitService kitService;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        kitConfig = new KitConfig(this);
        kitConfig.load();
        cooldownManager = new CooldownManager(
                getDataFolder().toPath().resolve("cooldowns.yml"), getLogger());
        kitService = new KitService(this, cooldownManager);
        KitCommand kitCommand = new KitCommand(this, kitConfig, cooldownManager, kitService);
        getCommand("kit").setExecutor(kitCommand);
        getCommand("kit").setTabCompleter(kitCommand);
        getServer().getPluginManager().registerEvents(
                new KitMenuListener(kitConfig, cooldownManager, kitService), this);
        getLogger().info("KitPlugin включен. Наборов загружено: " + kitConfig.getKits().size());
    }

    @Override
    public void onDisable() {
        if (cooldownManager != null) {
            cooldownManager.save();
        }
    }
}
