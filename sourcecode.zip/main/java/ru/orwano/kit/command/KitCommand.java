package ru.orwano.kit.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ru.orwano.kit.KitPlugin;
import ru.orwano.kit.config.KitConfig;
import ru.orwano.kit.cooldown.CooldownManager;
import ru.orwano.kit.gui.KitMenu;
import ru.orwano.kit.kit.Kit;
import ru.orwano.kit.kit.KitResult;
import ru.orwano.kit.kit.KitService;
import ru.orwano.kit.util.TimeFormatter;

import java.util.List;
import java.util.Locale;

public class KitCommand implements CommandExecutor, TabCompleter {

    private final KitPlugin plugin;
    private final KitConfig kitConfig;
    private final CooldownManager cooldownManager;
    private final KitService kitService;

    public KitCommand(KitPlugin plugin, KitConfig kitConfig, CooldownManager cooldownManager, KitService kitService) {
        this.plugin = plugin;
        this.kitConfig = kitConfig;
        this.cooldownManager = cooldownManager;
        this.kitService = kitService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(kitConfig.message("players-only"));
            return true;
        }
        if (args.length > 1) {
            player.sendMessage(kitConfig.message("usage"));
            return true;
        }
        if (args.length == 0) {
            openMenu(player);
            return true;
        }
        Kit kit = kitConfig.getKit(args[0]);
        if (kit == null) {
            player.sendMessage(kitConfig.message("unknown-kit",
                    "%kit%", args[0],
                    "%list%", String.join(", ", availableNames(player))));
            return true;
        }
        handleResult(player, kit, kitService.give(player, kit));
        return true;
    }

    private void openMenu(Player player) {
        if (kitConfig.getKits().isEmpty()) {
            player.sendMessage(kitConfig.message("config-error", "%kit%", "-"));
            return;
        }
        new KitMenu(plugin, player, kitConfig, cooldownManager, kitService).show(player);
        player.sendMessage(kitConfig.message("gui-opened"));
    }

    private void handleResult(Player player, Kit kit, KitResult result) {
        switch (result) {
            case SUCCESS -> player.sendMessage(kitConfig.message("kit-received", "%kit%", kit.displayName()));
            case NO_PERMISSION -> player.sendMessage(kitConfig.message("no-permission", "%kit%", kit.displayName()));
            case ON_COOLDOWN -> {
                long remaining = cooldownManager.remainingSeconds(player.getUniqueId(), kit.id());
                player.sendMessage(kitConfig.message("cooldown",
                        "%kit%", kit.displayName(),
                        "%time%", TimeFormatter.format(remaining)));
            }
            case INVENTORY_FULL -> player.sendMessage(kitConfig.message("inventory-full-cancel"));
            case THROTTLED -> player.sendMessage(kitConfig.message("too-fast"));
            case GIVE_ERROR -> player.sendMessage(kitConfig.message("give-error", "%kit%", kit.displayName()));
        }
    }

    private List<String> availableNames(Player player) {
        return kitConfig.getKits().values().stream()
                .filter(kit -> kitService.canUse(player, kit))
                .map(Kit::id)
                .toList();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1 || !(sender instanceof Player player)) {
            return List.of();
        }
        String prefix = args[0].toLowerCase(Locale.ROOT);
        return availableNames(player).stream()
                .filter(name -> name.startsWith(prefix))
                .toList();
    }
}
