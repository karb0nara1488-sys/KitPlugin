package ru.orwano.kit.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import ru.orwano.kit.config.KitConfig;
import ru.orwano.kit.cooldown.CooldownManager;
import ru.orwano.kit.kit.Kit;
import ru.orwano.kit.kit.KitResult;
import ru.orwano.kit.kit.KitService;
import ru.orwano.kit.util.TimeFormatter;

import java.util.List;

public class KitMenuListener implements Listener {

    private final KitConfig kitConfig;
    private final CooldownManager cooldownManager;
    private final KitService kitService;

    public KitMenuListener(KitConfig kitConfig, CooldownManager cooldownManager, KitService kitService) {
        this.kitConfig = kitConfig;
        this.cooldownManager = cooldownManager;
        this.kitService = kitService;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (!(event.getInventory().getHolder() instanceof KitMenu)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof KitMenu)) {
            return;
        }
        if (event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT) {
            return;
        }
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) {
            return;
        }
        int slot = event.getSlot();
        List<Kit> kits = List.copyOf(kitConfig.getKits().values());
        if (slot < 0 || slot >= kits.size()) {
            return;
        }
        Kit kit = kits.get(slot);
        handleResult(player, kit, kitService.give(player, kit));
    }

    private void handleResult(Player player, Kit kit, KitResult result) {
        switch (result) {
            case SUCCESS -> {
                player.sendMessage(kitConfig.message("kit-received", "%kit%", kit.displayName()));
                player.closeInventory();
            }
            case NO_PERMISSION -> player.sendMessage(kitConfig.message("no-permission", "%kit%", kit.displayName()));
            case ON_COOLDOWN -> {
                long remaining = cooldownManager.remainingSeconds(player.getUniqueId(), kit.id());
                player.sendMessage(kitConfig.message("cooldown",
                        "%kit%", kit.displayName(),
                        "%time%", TimeFormatter.format(remaining)));
            }
            case INVENTORY_FULL -> player.sendMessage(kitConfig.message("inventory-full-cancel"));
            case THROTTLED -> player.sendMessage(kitConfig.message("too-fast"));
            case GIVE_ERROR -> player.sendMessage(kitConfig.message("give-error", "%kit%", kit.displayName()));
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof KitMenu) {
            event.setCancelled(true);
        }
    }
}
