package ru.orwano.kit.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.orwano.kit.KitPlugin;
import ru.orwano.kit.config.KitConfig;
import ru.orwano.kit.cooldown.CooldownManager;
import ru.orwano.kit.kit.Kit;
import ru.orwano.kit.kit.KitService;
import ru.orwano.kit.util.TimeFormatter;

import java.util.ArrayList;
import java.util.List;

public class KitMenu implements InventoryHolder {

    private static final String LORE_INTRO = "&7Нажмите на набор, чтобы получить его.";

    private final KitPlugin plugin;
    private final KitConfig kitConfig;
    private final CooldownManager cooldownManager;
    private final KitService kitService;
    private final Inventory inventory;

    public KitMenu(KitPlugin plugin, Player player, KitConfig kitConfig, CooldownManager cooldownManager, KitService kitService) {
        this.plugin = plugin;
        this.kitConfig = kitConfig;
        this.cooldownManager = cooldownManager;
        this.kitService = kitService;
        String title = plugin.getConfig().getString("gui.title", "&8Меню наборов");
        int rows = Math.min(6, Math.max(2, plugin.getConfig().getInt("gui.rows", 3)));
        this.inventory = Bukkit.createInventory(this, rows * 9, net.kyori.adventure.text.Component.text(color(title)));
        fill(player);
    }

    private void fill(Player player) {
        int slot = 0;
        for (Kit kit : kitConfig.getKits().values()) {
            if (slot >= inventory.getSize()) {
                break;
            }
            inventory.setItem(slot, createCard(player, kit));
            slot++;
        }
        ItemStack filler = fillerPane();
        for (int i = 0; i < inventory.getSize(); i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }

    private ItemStack createCard(Player player, Kit kit) {
        boolean hasPermission = kitService.canUse(player, kit);
        boolean admin = player.hasPermission("kit.admin");
        boolean onCooldown = hasPermission && !admin && cooldownManager.isOnCooldown(player.getUniqueId(), kit.id());

        ItemStack card = kit.icon().clone();
        card.setAmount(1);
        ItemMeta meta = card.getItemMeta();
        if (meta == null) {
            return card;
        }
        String title = hasPermission ? kit.displayName() : "&8" + plain(kit.displayName());
        meta.displayName(net.kyori.adventure.text.Component.text(color(title)));

        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        lore.add(net.kyori.adventure.text.Component.text(color(LORE_INTRO)));
        lore.add(net.kyori.adventure.text.Component.text(""));
        for (String line : kit.description()) {
            lore.add(net.kyori.adventure.text.Component.text(color(line)));
        }
        lore.add(net.kyori.adventure.text.Component.text(""));
        if (!hasPermission) {
            lore.add(net.kyori.adventure.text.Component.text(color("&c✖ Нет доступа")));
            lore.add(net.kyori.adventure.text.Component.text(color("&8Право: " + kit.permission())));
        } else if (onCooldown) {
            long remaining = cooldownManager.remainingSeconds(player.getUniqueId(), kit.id());
            lore.add(net.kyori.adventure.text.Component.text(color("&e⌛ Доступно через: &f" + TimeFormatter.format(remaining))));
        } else {
            lore.add(net.kyori.adventure.text.Component.text(color("&a✔ Доступен")));
        }
        if (hasPermission && kit.cooldownSeconds() > 0 && !onCooldown) {
            lore.add(net.kyori.adventure.text.Component.text(color("&8Перезарядка: " + TimeFormatter.format(kit.cooldownSeconds()))));
        }
        meta.lore(lore);
        card.setItemMeta(meta);
        return card;
    }

    private ItemStack fillerPane() {
        String materialName = plugin.getConfig().getString("gui.filler", "GRAY_STAINED_GLASS_PANE");
        Material material = Material.matchMaterial(materialName);
        if (material == null) {
            material = Material.GRAY_STAINED_GLASS_PANE;
        }
        return createPane(material);
    }

    private ItemStack createPane(Material material) {
        ItemStack pane = new ItemStack(material);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.displayName(net.kyori.adventure.text.Component.text("§r"));
            pane.setItemMeta(meta);
        }
        return pane;
    }

    private String color(String text) {
        return text.replace("&", "§");
    }

    private String plain(String text) {
        return text.replace("§", "");
    }

    public void show(Player player) {
        player.openInventory(inventory);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
