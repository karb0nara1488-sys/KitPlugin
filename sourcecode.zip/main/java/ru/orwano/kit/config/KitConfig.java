package ru.orwano.kit.config;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.orwano.kit.KitPlugin;
import ru.orwano.kit.kit.Kit;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class KitConfig {

    private final KitPlugin plugin;
    private final Map<String, Kit> kits = new LinkedHashMap<>();

    public KitConfig(KitPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        kits.clear();
        ConfigurationSection root = plugin.getConfig().getConfigurationSection("kits");
        if (root == null) {
            plugin.getLogger().severe("В config.yml отсутствует секция kits.");
            return;
        }
        for (String id : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(id);
            if (section == null) {
                continue;
            }
            try {
                Kit kit = readKit(id, section);
                if (kit.enabled()) {
                    kits.put(id.toLowerCase(), kit);
                }
            } catch (KitConfigException exception) {
                plugin.getLogger().severe("Набор '" + id + "' пропущен: " + exception.getMessage());
            }
        }
        if (kits.isEmpty()) {
            plugin.getLogger().severe("Не загружен ни один набор — проверьте секцию kits в config.yml.");
        }
    }

    public Kit getKit(String id) {
        return kits.get(id.toLowerCase());
    }

    public Map<String, Kit> getKits() {
        return kits;
    }

    public String message(String key, String... replacements) {
        String prefix = color(plugin.getConfig().getString("messages.prefix", ""));
        String text = plugin.getConfig().getString("messages." + key);
        if (text == null) {
            return prefix + "Сообщение '" + key + "' не найдено в config.yml.";
        }
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            text = text.replace(replacements[i], replacements[i + 1]);
        }
        return prefix + color(text);
    }

    private Kit readKit(String id, ConfigurationSection section) throws KitConfigException {
        Kit.Builder builder = Kit.builder(id.toLowerCase());
        builder.displayName(color(section.getString("name", id)));
        for (String line : section.getStringList("description")) {
            builder.description(List.of(color(line)));
        }
        builder.enabled(section.getBoolean("enabled", true));
        builder.cooldownSeconds(Math.max(0, section.getLong("cooldown", 0)));
        builder.permission(section.getString("permission", "kit." + id.toLowerCase()));

        Material iconMaterial = Material.matchMaterial(section.getString("icon", "STONE_PICKAXE"));
        if (iconMaterial == null || !iconMaterial.isItem()) {
            throw new KitConfigException("неизвестный материал иконки");
        }
        ItemStack icon = createItem(iconMaterial, 1, null, null, Map.of());
        builder.icon(icon);

        List<ItemStack> items = readItems(section);
        if (items.isEmpty()) {
            throw new KitConfigException("список items пуст или отсутствует");
        }
        builder.addItems(items);
        return builder.build();
    }

    private List<ItemStack> readItems(ConfigurationSection section) {
        List<ItemStack> result = new ArrayList<>();
        List<Map<?, ?>> rawItems = section.getMapList("items");
        if (rawItems.isEmpty()) {
            plugin.getLogger().severe("Набор '" + section.getName() + "': items должен быть списком вида '- material: ...'.");
            return result;
        }
        int index = 0;
        for (Map<?, ?> rawItem : rawItems) {
            index++;
            ItemStack item = readItem(rawItem, index);
            if (item != null) {
                result.add(item);
            }
        }
        return result;
    }

    private ItemStack readItem(Map<?, ?> rawItem, int index) {
        String materialName = String.valueOf(rawItem.get("material"));
        Material material = Material.matchMaterial(materialName);
        if (material == null || !material.isItem()) {
            plugin.getLogger().severe("Предмет #" + index + ": неизвестный материал '" + materialName + "' — пропущен.");
            return null;
        }
        int amount = 1;
        Object rawAmount = rawItem.get("amount");
        if (rawAmount instanceof Number number) {
            amount = Math.max(1, number.intValue());
        }
        String name = rawItem.get("name") == null ? null : color(String.valueOf(rawItem.get("name")));
        List<String> lore = new ArrayList<>();
        if (rawItem.get("lore") instanceof List<?> loreLines) {
            for (Object line : loreLines) {
                lore.add(color(String.valueOf(line)));
            }
        }
        Map<Enchantment, Integer> enchantments = readEnchantments(rawItem.get("enchantments"), materialName);
        return createItem(material, amount, name, lore, enchantments);
    }

    private Map<Enchantment, Integer> readEnchantments(Object raw, String itemName) {
        Map<Enchantment, Integer> enchantments = new LinkedHashMap<>();
        if (!(raw instanceof ConfigurationSection || raw instanceof Map)) {
            return enchantments;
        }
        Map<?, ?> rawEnchantments = raw instanceof ConfigurationSection section
                ? section.getValues(false)
                : (Map<?, ?>) raw;
        for (Map.Entry<?, ?> entry : rawEnchantments.entrySet()) {
            String enchantmentName = String.valueOf(entry.getKey());
            Enchantment enchantment = Enchantment.getByName(enchantmentName.toUpperCase());
            if (enchantment == null) {
                plugin.getLogger().severe("Предмет '" + itemName + "': неизвестное зачарование '" + enchantmentName + "' — пропущено.");
                continue;
            }
            int level = 1;
            if (entry.getValue() instanceof Number number) {
                level = number.intValue();
            }
            if (level < 1 || level > enchantment.getMaxLevel()) {
                plugin.getLogger().severe("Предмет '" + itemName + "': некорректный уровень зачарования '" + enchantmentName + ": " + level + "' — пропущено.");
                continue;
            }
            enchantments.put(enchantment, level);
        }
        return enchantments;
    }

    private ItemStack createItem(Material material, int amount, String name, List<String> lore, Map<Enchantment, Integer> enchantments) {
        ItemStack item = new ItemStack(material);
        item.setAmount(Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            if (name != null) {
                meta.displayName(net.kyori.adventure.text.Component.text(name));
            }
            if (lore != null && !lore.isEmpty()) {
                List<net.kyori.adventure.text.Component> loreComponents = new ArrayList<>();
                for (String line : lore) {
                    loreComponents.add(net.kyori.adventure.text.Component.text(line));
                }
                meta.lore(loreComponents);
            }
            item.setItemMeta(meta);
        }
        for (Map.Entry<Enchantment, Integer> entry : enchantments.entrySet()) {
            item.addUnsafeEnchantment(entry.getKey(), entry.getValue());
        }
        return item;
    }

    private String color(String text) {
        return text.replace("&", "§");
    }

    private static final class KitConfigException extends Exception {

        private KitConfigException(String message) {
            super(message);
        }
    }
}
