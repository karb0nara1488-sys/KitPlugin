package ru.orwano.kit.cooldown;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;

public class CooldownManager {

    private final Path file;
    private final Logger logger;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public CooldownManager(Path file, Logger logger) {
        this.file = file;
        this.logger = logger;
        load();
    }

    public synchronized boolean isOnCooldown(UUID playerId, String kitId) {
        return remainingSeconds(playerId, kitId) > 0;
    }

    public synchronized long remainingSeconds(UUID playerId, String kitId) {
        Map<String, Long> playerCooldowns = cooldowns.get(playerId);
        if (playerCooldowns == null) {
            return 0;
        }
        Long expiresAt = playerCooldowns.get(kitId);
        if (expiresAt == null) {
            return 0;
        }
        long remainingMillis = expiresAt - System.currentTimeMillis();
        if (remainingMillis <= 0) {
            playerCooldowns.remove(kitId);
            if (playerCooldowns.isEmpty()) {
                cooldowns.remove(playerId);
            }
            return 0;
        }
        return (remainingMillis + 999) / 1000;
    }

    public synchronized void setCooldown(UUID playerId, String kitId, long seconds) {
        if (seconds <= 0) {
            return;
        }
        cooldowns.computeIfAbsent(playerId, key -> new HashMap<>())
                .put(kitId, System.currentTimeMillis() + seconds * 1000L);
        save();
    }

    public synchronized void load() {
        cooldowns.clear();
        if (!Files.exists(file)) {
            return;
        }
        try {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file.toFile());
            ConfigurationSection root = yaml.getConfigurationSection("cooldowns");
            if (root == null) {
                return;
            }
            for (String playerKey : root.getKeys(false)) {
                UUID playerId;
                try {
                    playerId = UUID.fromString(playerKey);
                } catch (IllegalArgumentException exception) {
                    logger.warning("cooldowns.yml: некорректный UUID '" + playerKey + "' — пропущен.");
                    continue;
                }
                ConfigurationSection playerSection = root.getConfigurationSection(playerKey);
                if (playerSection == null) {
                    continue;
                }
                for (String kitId : playerSection.getKeys(false)) {
                    long expiresAt = playerSection.getLong(kitId, 0);
                    if (expiresAt > System.currentTimeMillis()) {
                        cooldowns.computeIfAbsent(playerId, key -> new HashMap<>()).put(kitId.toLowerCase(), expiresAt);
                    }
                }
            }
        } catch (Exception exception) {
            logger.severe("Не удалось прочитать cooldowns.yml: " + exception.getMessage());
        }
    }

    public synchronized void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Long>> playerEntry : cooldowns.entrySet()) {
            for (Map.Entry<String, Long> kitEntry : playerEntry.getValue().entrySet()) {
                yaml.set("cooldowns." + playerEntry.getKey() + "." + kitEntry.getKey(), kitEntry.getValue());
            }
        }
        try {
            Files.createDirectories(file.getParent());
            yaml.save(file.toFile());
        } catch (IOException exception) {
            logger.severe("Не удалось сохранить cooldowns.yml: " + exception.getMessage());
        }
    }
}
