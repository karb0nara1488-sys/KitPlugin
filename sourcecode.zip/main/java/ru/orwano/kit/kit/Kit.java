package ru.orwano.kit.kit;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public record Kit(
        String id,
        String displayName,
        List<String> description,
        ItemStack icon,
        String permission,
        long cooldownSeconds,
        boolean enabled,
        List<ItemStack> items
) {

    public Kit {
        description = List.copyOf(description);
        items = List.copyOf(items);
    }

    public static Builder builder(String id) {
        return new Builder(id);
    }

    public static final class Builder {

        private final String id;
        private String displayName;
        private final List<String> description = new ArrayList<>();
        private ItemStack icon;
        private String permission;
        private long cooldownSeconds;
        private boolean enabled = true;
        private final List<ItemStack> items = new ArrayList<>();

        private Builder(String id) {
            this.id = id;
            this.displayName = id;
        }

        public Builder displayName(String displayName) {
            this.displayName = displayName;
            return this;
        }

        public Builder description(List<String> description) {
            this.description.addAll(description);
            return this;
        }

        public Builder icon(ItemStack icon) {
            this.icon = icon;
            return this;
        }

        public Builder permission(String permission) {
            this.permission = permission;
            return this;
        }

        public Builder cooldownSeconds(long cooldownSeconds) {
            this.cooldownSeconds = cooldownSeconds;
            return this;
        }

        public Builder enabled(boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public Builder addItems(List<ItemStack> stacks) {
            for (ItemStack stack : stacks) {
                items.add(stack.clone());
            }
            return this;
        }

        public Kit build() {
            List<ItemStack> result = new ArrayList<>();
            for (ItemStack stack : items) {
                int remaining = Math.max(1, stack.getAmount());
                int maxSize = Math.max(1, stack.getMaxStackSize());
                while (remaining > 0) {
                    int part = Math.min(maxSize, remaining);
                    ItemStack piece = stack.clone();
                    piece.setAmount(part);
                    result.add(piece);
                    remaining -= part;
                }
            }
            return new Kit(id, displayName, description, icon, permission, cooldownSeconds, enabled, result);
        }
    }
}
