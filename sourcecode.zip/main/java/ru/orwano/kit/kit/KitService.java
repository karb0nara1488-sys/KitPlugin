package ru.orwano.kit.kit;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.orwano.kit.KitPlugin;
import ru.orwano.kit.cooldown.CooldownManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class KitService {

    private static final long GIVE_THROTTLE_MILLIS = 500L;

    private final KitPlugin plugin;
    private final CooldownManager cooldownManager;
    private final Map<UUID, Long> lastGiveAt = new HashMap<>();

    public KitService(KitPlugin plugin, CooldownManager cooldownManager) {
        this.plugin = plugin;
        this.cooldownManager = cooldownManager;
    }

    public boolean canUse(Player player, Kit kit) {
        return player.hasPermission("kit.admin") || player.hasPermission(kit.permission());
    }

    public KitResult give(Player player, Kit kit) {
        if (!canUse(player, kit)) {
            return KitResult.NO_PERMISSION;
        }
        if (!player.hasPermission("kit.admin") && cooldownManager.isOnCooldown(player.getUniqueId(), kit.id())) {
            return KitResult.ON_COOLDOWN;
        }
        if (!acquireThrottle(player.getUniqueId())) {
            return KitResult.THROTTLED;
        }
        if (!fits(player, kit.items())) {
            return KitResult.INVENTORY_FULL;
        }
        try {
            HashMap<Integer, ItemStack> leftover =
                    player.getInventory().addItem(kit.items().toArray(ItemStack[]::new));
            int passes = 0;
            while (!leftover.isEmpty() && passes < 3) {
                passes++;
                leftover = player.getInventory().addItem(leftover.values().toArray(ItemStack[]::new));
            }
            if (!leftover.isEmpty()) {
                plugin.getLogger().severe("Не удалось разместить предметы набора '" + kit.id()
                        + "' в инвентаре игрока " + player.getName());
                return KitResult.GIVE_ERROR;
            }
        } catch (Exception exception) {
            plugin.getLogger().severe("Ошибка выдачи набора '" + kit.id() + "': " + exception.getMessage());
            return KitResult.GIVE_ERROR;
        }
        if (!player.hasPermission("kit.admin")) {
            cooldownManager.setCooldown(player.getUniqueId(), kit.id(), kit.cooldownSeconds());
        }
        return KitResult.SUCCESS;
    }

    private boolean acquireThrottle(UUID playerId) {
        synchronized (lastGiveAt) {
            long now = System.currentTimeMillis();
            Long last = lastGiveAt.get(playerId);
            if (last != null && now - last < GIVE_THROTTLE_MILLIS) {
                return false;
            }
            lastGiveAt.put(playerId, now);
            return true;
        }
    }

    private boolean fits(Player player, List<ItemStack> items) {
        Map<Integer, Integer> reserved = new HashMap<>();
        Map<Integer, ItemStack> reservedFor = new HashMap<>();
        for (ItemStack item : items) {
            int remaining = item.getAmount();
            int maxSize = Math.max(1, item.getMaxStackSize());
            for (int slot = 0; slot < 36 && remaining > 0; slot++) {
                if (reservedFor.containsKey(slot)) {
                    if (reservedFor.get(slot).isSimilar(item)) {
                        int free = reserved.get(slot);
                        int used = Math.min(free, remaining);
                        if (used > 0) {
                            reserved.put(slot, free - used);
                            remaining -= used;
                        }
                    }
                    continue;
                }
                ItemStack current = player.getInventory().getItem(slot);
                if (current == null || current.getType().isAir()) {
                    int used = Math.min(maxSize, remaining);
                    reserved.put(slot, maxSize - used);
                    reservedFor.put(slot, item.clone());
                    remaining -= used;
                } else if (current.isSimilar(item)) {
                    int capacity = maxSize - current.getAmount();
                    int used = Math.min(capacity, remaining);
                    if (used > 0) {
                        reserved.put(slot, capacity - used);
                        reservedFor.put(slot, item.clone());
                        remaining -= used;
                    }
                }
            }
            if (remaining > 0) {
                return false;
            }
        }
        return true;
    }
}
