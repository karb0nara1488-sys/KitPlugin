package ru.orwano.kit.kit;

public enum KitResult {

    SUCCESS,
    NO_PERMISSION,
    ON_COOLDOWN,
    INVENTORY_FULL,
    THROTTLED,
    GIVE_ERROR
}
